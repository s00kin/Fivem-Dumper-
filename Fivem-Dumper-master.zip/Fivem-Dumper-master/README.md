# Fivem-Dumper
FiveM cheat that allows you to download client side files

GUI Developed by me, dumper developed by marcodsl ( https://github.com/marcodsl/FiveM-Client-Dumper/releases )
